from tabulate import tabulate

import seaborn as sns
import matplotlib.pyplot as plt
import random

i = 0
dice = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0}
weights = [1, 1, 1, 1, 1, 5]

while i < 1000:
    i += 1
    roll = random.choices([1, 2, 3, 4, 5, 6], weights=weights)[0]
    dice[roll] += 1

table_data = [[key, value, (value / 10)] for key, value in dice.items()]
print(
    tabulate(
        table_data, headers=["Dice Number", "Rolls", "Percentage"], tablefmt="grid"
    )
)

sns.barplot(x=list(dice.keys()), y=list(dice.values()))
plt.title("Dice Rolls")
plt.xlabel("Dice Number")
plt.ylabel("Rolls")
plt.show()
