import seaborn as sns
import matplotlib.pyplot as plt
import random

i = 0
dice = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0}

while i < 1000:
    i += 1
    dice[random.randint(1, 6)] += 1

for key, value in dice.items():
    mean = sum(dice.values()) / len(dice)

print("Average:", mean)

sns.barplot(x=list(dice.keys()), y=list(dice.values()))
plt.title("Dice Rolls")
plt.xlabel("Dice Number")
plt.ylabel("Rolls")
plt.show()
